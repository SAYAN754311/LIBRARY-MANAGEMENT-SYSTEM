# Project Report Template

Use `Project_Report.pdf` as the completed report included with the repository. If your institution requires a source-editable report, copy the report sections into your required template and fill in student details.

Required personal fields:
- Student Name
- Register Number
- Course / Class
- Institution
